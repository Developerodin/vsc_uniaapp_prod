# Android Upload Keystore Credentials

These credentials are used in conjunction with your Android upload keystore file to sign your app for distribution.

## Credential Values

- Android upload keystore password: 130b225bb4e8e812d4ddc39482f6b456
- Android key alias: 6279695c477edbb7b0c29efa10a3ee34
- Android key password: c66b39b20a05d26d3b50d94bc9a5a05e
      